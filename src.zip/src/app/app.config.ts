export const optionsData = [
    {
      name: 'Install',
      value: 'Install'
    },
    {
      name: 'Normal',
      value: 'Normal'
    },
    {
      name: 'Debug',
      value: 'Debug'
    },
    {
      name: 'Advanced',
      value: 'Advanced'
    }
];