export const liaisonData = {
    "$schema": {
      "type": "string",
      "format": "uri"
    },
    "type": "object",
    "properties": {
      "AmazonWebServices": {
        "type": "object",
        "properties": {
          "ProfilesLocation": {
            "description": "AWS credientials file path. If null, use default one. (C:\\Users\\Liaison\\.aws\\credentials)",
            "category": "Install",
            "type": "string",
            "default": "C:\\Users\\keiji\\.aws\\credentials"
          },
          "ProfileName": {
            "description": "AWS credientials profile name. (default)",
            "category": "Advanced",
            "type": "string",
            "default": "default"
          },
          "SetUserProfileEnvironmentVariableValue": {
            "description": "AWS credientials profile environment variable value. this is quick hack. If IIS setting, Load User Profile true, USERPROFILE environment should be set. But actually not set. AWSSDK internally use USERPROFILE. and it goes to wrong path. (C:\\Users\\Liaison)",
            "category": "Install",
            "type": "string",
            "default": "C:\\Users\\keiji"
          },
          "RegionEndpointName": {
            "description": "Amazon authentication region end point name",
            "category": "Advanced",
            "type": "string",
            "default": "us-east-1"
          },
          "RegionEndpointNameEcr": {
            "description": "Amazon ECR authentication region end point name",
            "category": "Advanced",
            "type": "string",
            "default": "us-east-1"
          },
          "RegionEndpointNameS3": {
            "description": "Amazon Simple storage service authentication region end point name",
            "category": "Advanced",
            "type": "string",
            "default": "us-east-1"
          },
          "RegionEndpointNameCloudWatch": {
            "description": "Amazon CloudWtch authentication region end point name",
            "category": "Advanced",
            "type": "string",
            "default": "us-east-1"
          },
          "EcrProxyEndpointUrl": {
            "description": "The registry URL to use for this authorization token in a docker login command. The Amazon ECR registry URL format is https://aws_account_id.dkr.ecr.region.amazonaws.com. For example, https://012345678910.dkr.ecr.us-east-1.amazonaws.com. If null, inference access amazon to retrieve it.",
            "category": "Advanced",
            "type": "string"
          },
          "SimpleStorageServiceBucketName": {
            "description": "Amazon Simple storage service bucket name",
            "category": "Advanced",
            "type": "string",
            "default": "keiji-test"
          }
        },
        "additionalProperties": false
      },
      "AspNetCore": {
        "type": "object",
        "properties": {
          "CreateMiniDumpForException": {
            "description": "This is debug purpose. If true, create Minidump if exception happens. Works only on Windows",
            "category": "Debug",
            "type": "boolean",
            "default": false
          }
        },
        "additionalProperties": false
      },
      "Core": {
        "type": "object",
        "properties": {
          "DataPath": {
            "description": "Data storage path",
            "category": "Install",
            "type": "string",
            "default": "C:\\data"
          },
          "DebugPath": {
            "description": "Debug log path",
            "category": "Debug",
            "type": "string",
            "default": "C:\\data\\logs\\debug"
          },
          "EnableAspNetCoreLog": {
            "description": "Enable AspNetCore log. If you need detail information of Web service relating, enable it. (false)",
            "category": "Debug",
            "type": "boolean",
            "default": false
          },
          "EnableEntityFrameworkLog": {
            "description": "Enable Entity Framework log. If you need detail information of database relating, enable it. (false)",
            "category": "Debug",
            "type": "boolean",
            "default": false
          },
          "MemoryDump": {
            "description": "MemoryDump setting",
            "category": "Debug",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "DumpPath": {
                "description": "Mini dump path",
                "category": "Debug",
                "type": "string",
                "default": "C:\\data\\logs\\dump"
              },
              "WindowsMemoryDumpType": {
                "description": "Mini dump type. same as DumpType in hex",
                "category": "Debug",
                "type": "string"
              },
              "WindowsMemoryDumpTypeInInt": {
                "description": null,
                "category": "Normal",
                "type": "number",
                "default": 0
              }
            }
          },
          "Proxy": {
            "description": "Proxy configuration",
            "category": "Normal",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "Host": {
                "description": "If proxy is required to communicate with inference or AWS, set proxy address here. otherwise null.",
                "category": "Normal",
                "type": "string",
                "default": ""
              },
              "Port": {
                "description": "If proxy is required to communicate with inference or AWS, set proxy port number here. otherwise 0.",
                "category": "Normal",
                "type": "number",
                "default": 0
              },
              "Username": {
                "description": "If proxy auth is required, set username here. otherwise null",
                "category": "Normal",
                "type": "string",
                "default": ""
              },
              "Password": {
                "description": "If proxy auth is required, set password here. otherwise null",
                "category": "Normal",
                "type": "string",
                "default": ""
              }
            }
          }
        },
        "additionalProperties": false
      },
      "DicomAnonymizer": {
        "type": "object",
        "properties": {
          "UseDicomPart15": {
            "description": "Use DICOM part15 Table E.1-1",
            "category": "Advanced",
            "type": "boolean",
            "default": false
          },
          "ConfidentialityOption": {
            "description": "This setting works only DICOM table mode.\r\nBasicProfile,\r\nRetainUids,\r\nRetainDeviceIdentity,\r\nRetainInstitutionIdentity,\r\nRetainPatientCharacteristics,\r\nRetainLongitudinalTemporalInformationWithFullDates,\r\nRetainLongitudinalTemporalInformationWithModifiedDates\r\n\r\nCleanDescriptors, CleanStructuredContent, CleanGraphics are not tested.\r\n\r\nRetainSafePrivate, CleanPixelData, CleanRecognizableVisualFeatures are not implemented",
            "category": "Advanced",
            "type": "array",
            "default": "BasicProfile",
            "items": {
              "type": "string",
              "enum": [
                "BasicProfile",
                "RetainSafePrivate",
                "RetainUids",
                "RetainDeviceIdentity",
                "RetainInstitutionIdentity",
                "RetainPatientCharacteristics",
                "RetainLongitudinalTemporalInformationWithFullDates",
                "RetainLongitudinalTemporalInformationWithModifiedDates",
                "CleanDescriptors",
                "CleanStructuredContent",
                "CleanGraphics",
                "CleanPixelData",
                "CleanRecognizableVisualFeatures"
              ]
            }
          },
          "OverwriteActions": {
            "description": "This setting works only DICOM table mode.\r\nD,Z,X,K,C,U is allowed or mix ex. XZD\r\nD - replace with a non-zero length value that may be a dummy value and consistent with the VR\r\nZ - replace with a zero length value, or a non-zero length value that may be a dummy value and consistent with the VR\r\nX - remove\r\nK - keep (unchanged for non-sequence attributes, cleaned for sequences)\r\nC - clean, that is replace with values of similar meaning known not to contain identifying information and consistent with the VR\r\nU - replace with a non-zero length UID that is internally consistent within a set of Instances\r\nZ/D - Z unless D is required to maintain IOD conformance (Type 2 versus Type 1)\r\nX/Z - X unless Z is required to maintain IOD conformance (Type 3 versus Type 2)\r\nX/D - X unless D is required to maintain IOD conformance (Type 3 versus Type 1)\r\nX/Z/D - X unless Z or D is required to maintain IOD conformance (Type 3 versus Type 2 versus Type 1)\r\nX/Z/U* - X unless Z or replacement of contained instance UIDs (U) is required to maintain IOD conformance (Type 3 versus Type 2 versus Type 1 sequences containing UID references)",
            "category": "Advanced",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "object",
              "additionalProperties": false,
              "properties": {
                "Tag": {
                  "description": "Tag to overwrite the action",
                  "category": "Advanced",
                  "type": "string",
                  "pattern": "^0x[0-9a-fA-F]{8}"
                },
                "ActionCode": {
                  "description": "Action to overwrite",
                  "category": "Advanced",
                  "type": "array",
                  "items": {
                    "type": "string",
                    "enum": [
                      "Null",
                      "D",
                      "Z",
                      "ZD",
                      "X",
                      "XD",
                      "XZ",
                      "XZD",
                      "K",
                      "C",
                      "U",
                      "XZU"
                    ]
                  }
                }
              }
            }
          },
          "ConfidentialityOptionsEai": {
            "description": "This setting works only EAI table mode.\r\nDefault,\r\nEnvoyAIRetainSafePrivateTags,\r\nEnvoyAIKeepPatientCharacteristics,\r\nEnvoyAIKeepPatientMetabolicCharacteristics,\r\nKeepPatientCharacteristics,\r\nKeepPatientSex,\r\nKeepPatientAge,\r\nEnvoyAICleanDescriptorOption,\r\nEnvoyAISafeDescriptorOption,\r\nEnvoyAIRetainDeviceIdentityOption,\r\nRetainDeviceIdentityOption\r\n",
            "category": "Normal",
            "type": "array",
            "default": "EmptyDate",
            "items": {
              "type": "string",
              "enum": [
                "Default",
                "EnvoyAIRetainSafePrivateTags",
                "EnvoyAIKeepPatientCharacteristics",
                "EnvoyAIKeepPatientMetabolicCharacteristics",
                "KeepPatientCharacteristics",
                "KeepPatientSex",
                "KeepPatientAge",
                "EnvoyAICleanDescriptorOption",
                "EnvoyAISafeDescriptorOption",
                "EnvoyAIRetainDeviceIdentityOption",
                "RetainDeviceIdentityOption",
                "EmptyDate",
                "EnvoyAISafeCleanPixelData"
              ]
            }
          },
          "MaxLengthOfHashToReplace": {
            "description": "This setting works only EAI table mode.\r\nThis parameter crop the length of the HASH string. may be 64 or 16 or 0",
            "category": "Advanced",
            "type": "number",
            "default": 16
          }
        },
        "additionalProperties": false
      },
      "Dicom": {
        "type": "object",
        "properties": {
          "ApplicationName": {
            "description": null,
            "category": "Normal",
            "type": "string",
            "default": "SettingSchemaGen2"
          },
          "ImplementationVersionName": {
            "description": null,
            "category": "Normal",
            "type": "string",
            "default": "1.0.0.0"
          },
          "ImplementationClassUid": {
            "description": "DICOM The DICOM Implementation Class UID (as specified in your DICOM conformance statement).",
            "category": "Advanced",
            "type": "string",
            "default": "2.16.840.1.113669.632.21.777"
          },
          "Uid": {
            "description": "DICOM The rule of how to create new Uid",
            "category": "Advanced",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "Root": {
                "description": "DICOM The rule of how to create new Uid (Root)",
                "category": "Advanced",
                "type": "string",
                "default": "2.16.840.1.114053"
              },
              "Occupancy": {
                "description": "DICOM The rule of how to create new Uid (Occupancy)",
                "category": "Advanced",
                "type": "string",
                "default": "5500"
              },
              "DeviceType": {
                "description": "DICOM The rule of how to create new Uid (DeviceType)",
                "category": "Advanced",
                "type": "string",
                "default": "1"
              },
              "InstanceCreator": {
                "description": "DICOM The rule of how to create new Uid (InstanceCreator)",
                "category": "Advanced",
                "type": "string",
                "default": "1"
              },
              "StudyInstance": {
                "description": "DICOM The rule of how to create new Uid (StudyInstance)",
                "category": "Advanced",
                "type": "string",
                "default": "2"
              },
              "SeriesInstance": {
                "description": "DICOM The rule of how to create new Uid (SeriesInstance)",
                "category": "Advanced",
                "type": "string",
                "default": "3"
              },
              "SopInstance": {
                "description": "DICOM The rule of how to create new Uid (SopInstance)",
                "category": "Advanced",
                "type": "string",
                "default": "4"
              },
              "FrameOfReference": {
                "description": "DICOM The rule of how to create new Uid (FrameOfReference)",
                "category": "Advanced",
                "type": "string",
                "default": "5"
              }
            }
          },
          "CallingAe": {
            "description": "DICOM Calling AE Title for SCU",
            "category": "Normal",
            "type": "string",
            "default": "envoy-scu"
          },
          "DefaultTransferSyntax": {
            "description": "DefaultTransferSytax",
            "category": "Advanced",
            "type": "string",
            "default": "1.2.840.10008.1.2.1"
          }
        },
        "additionalProperties": false
      },
      "FoDicom": {
        "type": "object",
        "properties": {
          "EnableFoDicomLog": {
            "description": "This is debug purpose. always false. If true, FoDicom relating log are enabled.",
            "category": "Debug",
            "type": "boolean",
            "default": false
          },
          "SuppressAutoValidate": {
            "description": null,
            "category": "Normal",
            "type": "boolean",
            "default": true
          }
        },
        "additionalProperties": false
      },
      "DicomJobs": {
        "type": "object",
        "properties": {
          "RetryCStoreIntervalTimeInMinutes": {
            "description": "How often DICOM CStore try if server returns error [1, 10, 30, 60, 90] means 1st time, 1 minutes later, 2nd time, 10 min later, 3rd time, 30 min later.... 5 times tried then give up",
            "category": "Advanced",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "number"
            }
          },
          "RetryStowRsIntervalTimeInMinutes": {
            "description": "How often DICOM STOW-RS try if server returns error [1, 10, 30, 60, 90] means 1st time, 1 minutes later, 2nd time, 10 min later, 3rd time, 30 min later.... 5 times tried then give up",
            "category": "Advanced",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "number"
            }
          }
        },
        "additionalProperties": false
      },
      "DicomService": {
        "type": "object",
        "properties": {
          "DicomTcpIpPort": {
            "description": "DICOM TCP/IP port number for SCP",
            "category": "Install",
            "type": "number",
            "default": 104
          },
          "TranscodeWhenRecieveData": {
            "description": "If true, transcoded to DefaultTransferSytax then store.",
            "category": "Advanced",
            "type": "boolean",
            "default": true
          },
          "OverwriteForSameData": {
            "description": "Don't overwrite storage if same data is pushed.",
            "category": "Advanced",
            "type": "boolean",
            "default": false
          },
          "WaitTimeForNewSeriesArriveInSeconds": {
            "description": "New Series Notification is fired after this seconds.",
            "category": "Advanced",
            "type": "number",
            "default": 5
          },
          "WaitTimeForNewStudyArriveInSeconds": {
            "description": "New Study Notification is fired after this seconds.",
            "category": "Advanced",
            "type": "number",
            "default": 10
          },
          "WaitTimeForNewPatientArriveInSeconds": {
            "description": "New Patient Notification is fired after this seconds.",
            "category": "Advanced",
            "type": "number",
            "default": 20
          },
          "AcceptedImageTransferSyntaxes": {
            "description": "When SCU is requested, which transfer syntax are accept. List of transfer syntax uid",
            "category": "Normal",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "object",
              "additionalProperties": false,
              "properties": {
                "UID": {
                  "description": null,
                  "category": "Normal",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {
                    "RootUID": {
                      "description": null,
                      "category": "Normal",
                      "type": "string"
                    },
                    "UID": {
                      "description": null,
                      "category": "Normal",
                      "type": "string"
                    },
                    "Name": {
                      "description": null,
                      "category": "Normal",
                      "type": "string"
                    },
                    "Type": {
                      "description": null,
                      "category": "Normal",
                      "type": "string",
                      "enum": [
                        "TransferSyntax",
                        "SOPClass",
                        "MetaSOPClass",
                        "ServiceClass",
                        "SOPInstance",
                        "ApplicationContextName",
                        "ApplicationHostingModel",
                        "CodingScheme",
                        "FrameOfReference",
                        "LDAP",
                        "MappingResource",
                        "ContextGroupName",
                        "Unknown"
                      ]
                    },
                    "IsRetired": {
                      "description": null,
                      "category": "Normal",
                      "type": "boolean"
                    },
                    "IsImageStorage": {
                      "description": null,
                      "category": "Normal",
                      "type": "boolean"
                    },
                    "IsVolumeStorage": {
                      "description": null,
                      "category": "Normal",
                      "type": "boolean"
                    },
                    "StorageCategory": {
                      "description": null,
                      "category": "Normal",
                      "type": "string",
                      "enum": [
                        "None",
                        "Image",
                        "PresentationState",
                        "StructuredReport",
                        "Waveform",
                        "Document",
                        "Raw",
                        "Other",
                        "Private",
                        "Volume"
                      ]
                    }
                  }
                },
                "IsRetired": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                },
                "IsExplicitVR": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                },
                "IsEncapsulated": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                },
                "IsLossy": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                },
                "LossyCompressionMethod": {
                  "description": null,
                  "category": "Normal",
                  "type": "string"
                },
                "IsDeflate": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                },
                "Endian": {
                  "description": null,
                  "category": "Normal",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {}
                },
                "SwapPixelData": {
                  "description": null,
                  "category": "Normal",
                  "type": "boolean"
                }
              }
            }
          },
          "CheckTransferSyntaxWithAcceptedImageTransferSyntax": {
            "description": "If true, when the data is SCUed, check transfer syntax. if doesn't accept, just reject",
            "category": "Advanced",
            "type": "boolean",
            "default": true
          },
          "CMoveDestinations": {
            "description": null,
            "category": "Normal",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "object",
              "additionalProperties": false,
              "properties": {
                "AETitle": {
                  "description": null,
                  "category": "Normal",
                  "type": "string"
                },
                "IPAddress": {
                  "description": null,
                  "category": "Normal",
                  "type": "string"
                },
                "Port": {
                  "description": null,
                  "category": "Normal",
                  "type": "number"
                }
              }
            }
          }
        },
        "additionalProperties": false
      },
      "DicomStore": {
        "type": "object",
        "properties": {
          "UpdateInfoInUpsert": {
            "description": "If same UID data is stored, overwrite the data (true), skip (false) Default false",
            "category": "Advanced",
            "type": "boolean",
            "default": false
          }
        },
        "additionalProperties": false
      },
      "DicomStoreSqlite": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "DicomTagMatch": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "DicomWebService": {
        "type": "object",
        "properties": {
          "TranscodeWhenRecieveData": {
            "description": "This is debug purpose. Always true. if true, StowRS triggers transcode transfer syntax.",
            "category": "Advanced",
            "type": "boolean",
            "default": true
          }
        },
        "additionalProperties": false
      },
      "EnvoyAiJobs": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "LiaisonJobs": {
        "type": "object",
        "properties": {
          "InferenceBaseUri": {
            "description": "Inference base uri. this uri is used to access inference",
            "category": "Install",
            "type": "string",
            "default": "http://localhost:4567",
            "format": "uri"
          },
          "LiaisonBaseUri": {
            "description": "Liaison base uri. this uri is used to access inference",
            "category": "Install",
            "type": "string",
            "default": "http://localhost:4566",
            "format": "uri"
          },
          "Authorization": {
            "description": "Authorization token to access inference docker image",
            "category": "Install",
            "type": "string",
            "default": "*"
          },
          "BatchPath": {
            "description": "This path is for batch log",
            "category": "Advanced",
            "type": "string",
            "default": "C:\\data\\LiaisonBatch"
          },
          "ValidateResult": {
            "description": "Validate result. if machine returns wrong result, it is recorded to log",
            "category": "Debug",
            "type": "boolean",
            "default": true
          },
          "TagFilter": {
            "description": "TagFilter configuration.",
            "category": "Advanced",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "MachinesPath": {
                "description": "tag filter machines json file folder path",
                "category": "Advanced",
                "type": "string",
                "default": "C:\\data\\config\\machines"
              },
              "RulesPath": {
                "description": "tag filter rules json file folder path",
                "category": "Advanced",
                "type": "string",
                "default": "C:\\data\\config\\rules"
              },
              "ConditionsPath": {
                "description": "tag filter condition json file folder path",
                "category": "Advanced",
                "type": "string",
                "default": "C:\\data\\config\\conditions"
              },
              "DefaultInputPathName": {
                "description": "Default input for machine are stored in here. It will be MachinePath/{machine-id}/{defaultInputs} and RulePath/{rule-name}/{defaultInputs}",
                "category": "Advanced",
                "type": "string",
                "default": "defaultInputs"
              }
            }
          },
          "Liaison": {
            "description": "Inference communication configuration",
            "category": "Normal",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "CommunicationMode": {
                "description": "How to communicate with Inference. Direct, ShareDrive, AmazonSimpleStorageService. If ShareDrive is set, inference needs to be set up to mount the drive.",
                "category": "Install",
                "type": "string",
                "default": "Direct",
                "enum": [
                  "Direct",
                  "ShareDrive",
                  "AmazonSimpleStorageService"
                ]
              },
              "ShareDrivePoint": {
                "description": "This folder is used to share input/output data for inference if CommunicationMode is FolderShare.",
                "category": "Install",
                "type": "string",
                "default": "C:\\Data\\SharedFolder"
              },
              "TranscodeWhenRecieveData": {
                "description": null,
                "category": "Normal",
                "type": "boolean",
                "default": true
              },
              "DebugLogDicomAfterDeIdentify": {
                "description": "This is debug purpose. always false. If true, liaision write anonymized data under DebugLogDicomPath.",
                "category": "Debug",
                "type": "boolean",
                "default": true
              },
              "DebugLogDicomBeforeReIdentify": {
                "description": "This is debug purpose. always false. If true, liaision write the result data before de-anonymize under DebugLogDicomPath.",
                "category": "Debug",
                "type": "boolean",
                "default": false
              },
              "RunningTimeoutAllowanceInSec": {
                "description": "Inference running timeout allowance in sec. As default, machine has docker timeout. but if inference needs to pull docker image, that time needs to be waited. this time is for that.",
                "category": "Advanced",
                "type": "number",
                "default": 60
              },
              "StatusCheckIntervalInSec": {
                "description": "Inference Status Check Interval in sec. How often Liaison checks inference status.",
                "category": "Advanced",
                "type": "number",
                "default": 10
              },
              "DebugResultKeep": {
                "description": "This is debug purpose. always false",
                "category": "Debug",
                "type": "boolean",
                "default": false
              },
              "AllowToInferenceAdditional": {
                "description": "Allow to pass additional SOP class UID to inference (config required)",
                "category": "Normal",
                "type": "boolean",
                "default": false
              },
              "AllowToInferenceTeraRecon": {
                "description": "Allow to pass additional SOP class UID to inference (only terarecon)",
                "category": "Normal",
                "type": "boolean",
                "default": false
              }
            }
          },
          "ResultDicomTagOverwriteRules": {
            "description": "Specify default dicom tag overwrite rule. after Liaison receive result from Inference, Liaison can overwrite some tags.",
            "category": "Advanced",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "object",
              "additionalProperties": false,
              "properties": {
                "Tag": {
                  "description": "After Liaison receives result, Liaison may modify DICOM tag. This tag is modified.",
                  "category": "Advanced",
                  "type": "string"
                },
                "Value": {
                  "description": "After Liaison receives result, Liaison may modify DICOM tag. This Value is used to modify.",
                  "category": "Advanced",
                  "type": "string"
                },
                "OverwriteOrAppend": {
                  "description": "After Liaison receives result, Liaison may modify DICOM tag. This decide Overwrite or Append",
                  "category": "Advanced",
                  "type": "string"
                }
              }
            }
          },
          "DefaultPushDestinationAfterValidate": {
            "description": "This aetitle is used to push the server if NS creates new DICOM object. Because NS cannot give batch-id",
            "category": "Advanced",
            "type": "array",
            "items": {
              "description": null,
              "category": "Normal",
              "type": "string"
            }
          },
          "Notification": {
            "description": "NS communication configuration",
            "category": "Normal",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "TimeOutInSec": {
                "description": "Timeout",
                "category": "Advanced",
                "type": "number",
                "default": 120
              },
              "RetryIntervalTimeInMinutes": {
                "description": "How often try to nofity if NS returns error [1, 10, 30, 60, 90] means 1st time, 1 minutes later, 2nd time, 10 min later, 3rd time, 30 min later.... 5 times tried then give up",
                "category": "Advanced",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "number"
                }
              },
              "DebugLog": {
                "description": "This is debug purpose. If this is true, Liaison writes notification log.",
                "category": "Debug",
                "type": "boolean",
                "default": true
              },
              "DestinationsNewStudyUrl": {
                "description": "When Liaison receives new data, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "DestinationsResultUrl": {
                "description": "When Liaison receives new result, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "DestinationsProgressUrl": {
                "description": "When Liaison receives progress or status, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "DicomDestinationsSeriesUrl": {
                "description": "When Liaison receives new data based on series, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "DicomDestinationsStudyUrl": {
                "description": "When Liaison receives new data based on study, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "DicomDestinationsPatientUrl": {
                "description": "When Liaison receives new data based on patient, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "string",
                  "format": "uri"
                }
              },
              "BatchNotificationsNewBatch": {
                "description": "When Liaison start new batch, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {
                    "Uri": {
                      "description": null,
                      "category": "Normal",
                      "type": "string",
                      "format": "uri"
                    },
                    "Contents": {
                      "description": null,
                      "category": "Normal",
                      "type": "array",
                      "items": {
                        "type": "string",
                        "enum": [
                          "Default",
                          "Status",
                          "Header",
                          "FindingSummary",
                          "Findings",
                          "SliceFindings",
                          "Dicom",
                          "All"
                        ]
                      }
                    }
                  }
                }
              },
              "BatchNotificationsResult": {
                "description": "When Liaison receives new result, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {
                    "Uri": {
                      "description": null,
                      "category": "Normal",
                      "type": "string",
                      "format": "uri"
                    },
                    "Contents": {
                      "description": null,
                      "category": "Normal",
                      "type": "array",
                      "items": {
                        "type": "string",
                        "enum": [
                          "Default",
                          "Status",
                          "Header",
                          "FindingSummary",
                          "Findings",
                          "SliceFindings",
                          "Dicom",
                          "All"
                        ]
                      }
                    }
                  }
                }
              },
              "BatchNotificationsProgress": {
                "description": "When Liaison receives progress or status, notification is fired. this is the destination uri",
                "category": "Normal",
                "type": "array",
                "items": {
                  "description": null,
                  "category": "Normal",
                  "type": "object",
                  "additionalProperties": false,
                  "properties": {
                    "Uri": {
                      "description": null,
                      "category": "Normal",
                      "type": "string",
                      "format": "uri"
                    },
                    "Contents": {
                      "description": null,
                      "category": "Normal",
                      "type": "array",
                      "items": {
                        "type": "string",
                        "enum": [
                          "Default",
                          "Status",
                          "Header",
                          "FindingSummary",
                          "Findings",
                          "SliceFindings",
                          "Dicom",
                          "All"
                        ]
                      }
                    }
                  }
                }
              }
            }
          },
          "InferenceCommunicationTimeoutInSec": {
            "description": "While communicating with inference, follows time out are used. in sec",
            "category": "Advanced",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "GetMachineAll": {
                "description": "GetMachineAll",
                "category": "Advanced",
                "type": "number",
                "default": 3600
              },
              "GetMachine": {
                "description": "GetMachine",
                "category": "Advanced",
                "type": "number",
                "default": 600
              },
              "StartEngine": {
                "description": "StartEngine",
                "category": "Advanced",
                "type": "number",
                "default": 600
              },
              "GetEngineStatus": {
                "description": "GetEngineStatus",
                "category": "Advanced",
                "type": "number",
                "default": 100
              },
              "GetResultJson": {
                "description": "GetResultJson",
                "category": "Advanced",
                "type": "number",
                "default": 100
              },
              "GetEngineLog": {
                "description": "GetEngineLog",
                "category": "Advanced",
                "type": "number",
                "default": 100
              }
            }
          },
          "Event": {
            "description": "Event log configuration.",
            "category": "Normal",
            "type": "object",
            "additionalProperties": false,
            "properties": {
              "Type": {
                "description": "Event log type. None,AmazonCloudWatch,File and mixed are used (AmazonCloudWatch|File).",
                "category": "Install",
                "type": "array",
                "default": "AmazonCloudWatch, File",
                "items": {
                  "type": "string",
                  "enum": [
                    "None",
                    "AmazonCloudWatch",
                    "File"
                  ]
                }
              },
              "SiteName": {
                "description": "If EventLog Type has AmazonCloudWatch, this site name is embedded.",
                "category": "Install",
                "type": "string",
                "default": "terarecon-test"
              },
              "ServerName": {
                "description": "If EventLog Type has AmazonCloudWatch, this server name is embedded.",
                "category": "Install",
                "type": "string",
                "default": "localhost"
              },
              "Source": {
                "description": "If EventLog Type has AmazonCloudWatch, this source is embedded.",
                "category": "Advanced",
                "type": "string",
                "default": "com.terarecon.antares"
              },
              "EnableInferenceLog": {
                "description": "If true, Event log will have inference log also (C# inference only).",
                "category": "Debug",
                "type": "boolean",
                "default": true
              }
            }
          }
        },
        "additionalProperties": false
      },
      "LiaisonWebService": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "JobManager": {
        "type": "object",
        "properties": {
          "DebugKeepRecordFinishedJob": {
            "description": "This is debug purpose. If true, finished job record are not deleted from database.",
            "category": "Debug",
            "type": "boolean",
            "default": false
          }
        },
        "additionalProperties": false
      },
      "JobManagerSqlite": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "NonDicomStore": {
        "type": "object",
        "properties": {
          "UpdateInfoInUpsert": {
            "description": "If same UID data is stored, overwrite the data (true), skip (false) Default false",
            "category": "Advanced",
            "type": "boolean",
            "default": false
          }
        },
        "additionalProperties": false
      },
      "NonDicomStoreSqlite": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "StreamStoreAmazonCloudWatch": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "StreamStoreAmazonSimpleStorageService": {
        "type": "object",
        "properties": {
          "CannedACL": {
            "description": "this CannedACL is used. private, public-read, public-read-write, authenticated-read, aws-exec-read, bucket-owner-read, bucket-owner-full-control, log-delivery-write",
            "category": "Advanced",
            "type": "string",
            "default": "private"
          },
          "StorageClass": {
            "description": "this StorageClass is used. STANDARD, REDUCED_REDUNDANCY, GLACIER, STANDARD_IA, ONEZONE_IA",
            "category": "Advanced",
            "type": "string",
            "default": "STANDARD"
          }
        },
        "additionalProperties": false
      },
      "StreamStore": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "StreamStoreFile": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "KeyValueStoreLog": {
        "type": "object",
        "properties": {},
        "additionalProperties": false
      },
      "Liaison": {
        "type": "object",
        "properties": {
          "DicomDataPath": {
            "description": "DICOM data storage path. If value is not set, Core.DataPath\\Dicom are used",
            "category": "Advanced",
            "type": "string",
            "default": "C:\\data\\Dicom"
          },
          "NonDicomDataPath": {
            "description": "NonDICOM data storage path. If value is not set, Core.DataPath\\NonDicom are used",
            "category": "Advanced",
            "type": "string",
            "default": "C:\\data\\NonDicom"
          }
        },
        "additionalProperties": false
      }
    }
}