import { Component, Output, EventEmitter, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-filter-options',
  templateUrl: './filter-options.component.html',
  styleUrls: ['./filter-options.component.scss']
})

export class FilterOptionsComponent {
  @Input() selectedOption: any;
  @Input() optionsData;
  @Output() optionClick = new EventEmitter();

  optionChanged() {
    this.optionClick.emit(this.selectedOption);
  }
}
