import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatListModule } from '@angular/material/list';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AppComponent } from './app.component';
import { FilterOptionsComponent } from './filter-options/filter-options.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { PropertiesComponent } from './properties/properties.component';
import { PropertyStringComponent } from './properties/property-string/property-string.component';
import { PropertyCheckBoxComponent } from './properties/property-checkbox/property-checkbox.component';
import { PropertyNumberComponent } from './properties/property-number/property-number.component';
import { PropertyDropdownComponent } from './properties/property-dropdown/property-dropdown.component';
import { PropertyRowComponent } from './properties/property-row/property-row.component';
import { PropertyComponent } from './properties/property/property.component';

@NgModule({
  declarations: [
    AppComponent,
    FilterOptionsComponent,
    PropertiesComponent,
    PropertyStringComponent,
    PropertyCheckBoxComponent,
    PropertyNumberComponent,
    PropertyDropdownComponent,
    PropertyRowComponent,
    PropertyComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatRadioModule,
    FormsModule,
    MatListModule,
    MatInputModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatButtonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
