import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-property-checkbox',
  templateUrl: './property-checkbox.component.html',
  styleUrls: ['./property-checkbox.component.scss']
})
export class PropertyCheckBoxComponent {

  @Input() data: any;

}
