import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-property-string',
  templateUrl: './property-string.component.html',
  styleUrls: ['./property-string.component.scss']
})
export class PropertyStringComponent {

  @Input() data: any;

}
