import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-property-row',
  templateUrl: './property-row.component.html',
  styleUrls: ['./property-row.component.scss']
})
export class PropertyRowComponent implements OnInit {

  @Input() data: any;

  ngOnInit() {
    this.data.value = [];
  }

  addRow() {
    this.data.value.push(this.data.items);
  }

  removeRow(index) {
    this.data.value = this.data.value.filter((item, i) => index !== i);
  }

}
