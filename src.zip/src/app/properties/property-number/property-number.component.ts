import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-property-number',
  templateUrl: './property-number.component.html',
  styleUrls: ['./property-number.component.scss']
})
export class PropertyNumberComponent {

  @Input() data: any;

}
