import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-property-dropdown',
  templateUrl: './property-dropdown.component.html',
  styleUrls: ['./property-dropdown.component.scss']
})
export class PropertyDropdownComponent {

  @Input() data: any;

}
