import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { MatRadioModule } from '@angular/material/radio';
import { MatListModule } from '@angular/material/list';
import { MatInputModule } from '@angular/material/input';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { ModeSelectorComponent } from './mode-selector/mode-selector.component';
import { TextComponent } from './text-component/text.component';
import { SchemaParamsComponent } from './schema-params/schema-params.component';
import { PreProcessComponent } from './pre-process/pre-process.component';
import { BooleanComponent } from './boolean-component/boolean-component';
import { PushRowListComponent } from './push-row-list/push-row-list.component';
import { CheckboxListComponent } from './checkbox-list/checkbox-list.component';
import { NumberComponent } from './number-component/number.component';
import { PostProcessComponent } from './post-process/post-process.component';
import { TagListComponent } from './tag-list/tag-list.component';

@NgModule({
  declarations: [
    AppComponent,
    ModeSelectorComponent,
    TextComponent,
    SchemaParamsComponent,
    PreProcessComponent,
    BooleanComponent,
    PushRowListComponent,
    CheckboxListComponent,
    NumberComponent,
    PostProcessComponent,
    TagListComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    MatRadioModule,
    FormsModule,
    MatListModule,
    MatInputModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatSelectModule,
    MatIconModule,
    MatButtonModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
