export const MODES = {
    DEFAULT: 'DEFAULT',
    ADVANCED: 'ADVANCED'
};

export const TYPES = {
    STRING: 'STRING',
    SCHEMA_PARAM_LIST: 'SCHEMA_PARAM_LIST',
    PRE_PROCESS: 'PRE_PROCESS',
    POST_PROCESS: 'POST_PROCESS',
    PUSH_ROW_LIST: 'PUSH_ROW_LIST',
    BOOLEAN: 'BOOLEAN',
    TAG_LIST: 'TAG_LIST',
    CHECKBOX_LIST: 'CHECKBOX_LIST',
    NUMBER: 'NUMBER'
};

const pushRowOptions = [
    {
        name: 'Called AETitle',
        prop: 'calledAeTitle'
    },
    {
        name: 'Hostname',
        prop: 'hostName'
    },
    {
        name: 'Port#',
        prop: 'port'
    }
];

const tagListOptions = [{
    tag: '00000000',
    name: 'Command Group Length',
    vr: 'UL'
}];

const dicomAnonymizerOverwriteActionsOpyions = [
    { text: 'EnvoyAI Retain Safe Private Tags', value: false },
    { text: 'EnvoyAI Keep Patient Characteristics', value: false }
];

const schemaInOptions = [
    {
        prop: 'condition',
        text: 'Condition'
    },
    {
        prop: 'setting',
        text: 'Setting'
    }
];

const postProcessConfig = {
    push: {
        type: TYPES.PUSH_ROW_LIST,
        mode: MODES.DEFAULT,
        text: 'Push',
        value: [],
        options: pushRowOptions
    },
    pushAfterValue: {
        type: TYPES.PUSH_ROW_LIST,
        mode: MODES.DEFAULT,
        text: 'Push After Validate',
        value: [],
        options: pushRowOptions
    },
    notifyNewResult: {
        type: TYPES.BOOLEAN,
        mode: MODES.ADVANCED,
        text: 'Notify New Result',
        value: true
    },
    resultDicomTagOverwrite: {
        type: TYPES.TAG_LIST,
        mode: MODES.ADVANCED,
        text: 'Result DICOM Tag Overwrites',
        value: [],
        options: tagListOptions
    },
    reasearchOnlyResult: {
        type: TYPES.BOOLEAN,
        mode: MODES.DEFAULT,
        text: 'Add Reasearch only to the Result',
        value: true
    }
};

const preProcessConfig = {
    notifyNewResult: {
        type: TYPES.BOOLEAN,
        mode: MODES.ADVANCED,
        text: 'Notify New Result',
        value: true
    },
    dicomAnonymizerOverwriteActions: {
        type: TYPES.CHECKBOX_LIST,
        mode: MODES.ADVANCED,
        text: 'Confidentiality Options',
        value: {},
        options: dicomAnonymizerOverwriteActionsOpyions
    },
    maxLengthOfHashToReplace: {
        type: TYPES.NUMBER,
        mode: MODES.ADVANCED,
        text: 'Max Length Of Hash To Replace',
        value: ''
    }
};

export const config = {
    name: {
        type: TYPES.STRING,
        mode: MODES.DEFAULT,
        text: 'Name',
        value: ''
    },
    description: {
        type: TYPES.STRING,
        mode: MODES.DEFAULT,
        text: 'Description',
        value: ''
    },
    machineId: {
        type: TYPES.STRING,
        mode: MODES.DEFAULT,
        text: 'Machine Id',
        value: ''
    },
    'schema-in': {
        type: TYPES.SCHEMA_PARAM_LIST,
        mode: MODES.DEFAULT,
        text: 'Schema In',
        options: schemaInOptions,
        value: {}
    },
    preProcess: {
        type: TYPES.PRE_PROCESS,
        mode: MODES.ADVANCED,
        text: 'Pre Process',
        config: preProcessConfig,
        value: {}
    },
    postProcess: {
        type: TYPES.POST_PROCESS,
        mode: MODES.DEFAULT,
        text: 'Post Process',
        config: postProcessConfig,
        value: {}
    }
};
