import { Component, Input } from '@angular/core';
import { KeyValue } from '@angular/common';

@Component({
  selector: 'app-schema-params',
  templateUrl: './schema-params.component.html',
  styleUrls: ['./schema-params.component.scss']
})
export class SchemaParamsComponent {

  @Input() data: any;

  getValue(obj: any) {
    if (!obj) { return ''; }
    const keys = Object.keys(obj);
    if (keys.length === 0) { return ''; }
    return keys[0];
  }

  keyChange(e: any, key: any) {
    const newKey = e.target.value;
    if (newKey === key) { return; }
    this.data.value[newKey] = this.data.value[key];
    delete this.data.value[key];
  }

  optionChange(e: any, key: any) {
    this.data.value[key] = {[e.value]: ''};
  }

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  }

  addParam() {
    if (Object.keys(this.data.value).some((n: any) => !n)) { return; }
    this.data.value[''] = {};
  }

  editParam() {

  }

  deleteParam(key: any) {
    delete this.data.value[key];
  }
}
