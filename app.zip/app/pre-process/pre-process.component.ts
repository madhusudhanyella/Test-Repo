import { Component, Input } from '@angular/core';
import { KeyValue } from '@angular/common';
import { TYPES } from '../app.config';

@Component({
  selector: 'app-pre-process',
  templateUrl: './pre-process.component.html',
  styleUrls: ['./pre-process.component.scss']
})
export class PreProcessComponent {

  @Input() data: any;
  TYPES;

  constructor() {
    this.TYPES = TYPES;
  }

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  }
  
}
