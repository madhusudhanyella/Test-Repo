import { Component, Input } from '@angular/core';
import { KeyValue } from '@angular/common';
import { TYPES, MODES } from '../app.config';

@Component({
  selector: 'app-post-process',
  templateUrl: './post-process.component.html',
  styleUrls: ['./post-process.component.scss']
})
export class PostProcessComponent {

  @Input() data: any;
  @Input() mode: any;
  TYPES;
  MODES;

  constructor() {
    this.TYPES = TYPES;
    this.MODES = MODES;
  }

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  }
  
}
