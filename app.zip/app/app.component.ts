import { Component } from '@angular/core';
import { config, TYPES, MODES } from './app.config';
import { KeyValue } from '@angular/common';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent {

  mode;
  properties;
  TYPES;
  MODES;

  constructor() {
    this.mode = MODES.DEFAULT;
    this.TYPES = TYPES;
    this.MODES = MODES;
    this.properties = config;
  }

  originalOrder = (a: KeyValue<number, string>, b: KeyValue<number, string>): number => {
    return 0;
  }

  modeChange(mode) {
    this.mode = mode;
  }

  readFile(event) {
    const selectedFile = event.target.files[0];
    const fileReader = new FileReader();
    fileReader.readAsText(selectedFile, 'UTF-8');
    fileReader.onload = (e: any) => {
      const fileInput = JSON.parse(e.target.result);
      Object.keys(this.properties).forEach((key: any) => {
        this.properties[key].value = fileInput[key];
      })
    };
    fileReader.onerror = (error) => {
      console.log(error);
    };
  }

}
