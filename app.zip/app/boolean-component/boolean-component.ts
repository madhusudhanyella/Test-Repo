import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-boolean',
  templateUrl: './boolean-component.html',
  styleUrls: ['./boolean-component.scss']
})
export class BooleanComponent {

  @Input() data: any;

}
