import { Component, Input, OnInit } from '@angular/core';

@Component({
  selector: 'app-push-row-list',
  templateUrl: './push-row-list.component.html',
  styleUrls: ['./push-row-list.component.scss']
})
export class PushRowListComponent implements OnInit {

  @Input() data: any;

  ngOnInit() {
    if (!this.data.value) {
      this.data.value = [];
    }
  }

  pushRow(){
    const obj = this.data.options.reduce((res: any, cur: any) => {
      res[cur.prop] = '';
      return res;
    }, {});
    this.data.value.push(obj);
  }

  deleteRow(r) {
    this.data.value.splice(r, 1);
  }

}
