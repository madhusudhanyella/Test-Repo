import { Component, Input, DoCheck, Output, EventEmitter, OnInit } from '@angular/core';
import { MODES } from '../app.config';

@Component({
  selector: 'app-mode-selector',
  templateUrl: './mode-selector.component.html',
  styleUrls: ['./mode-selector.component.scss']
})
export class ModeSelectorComponent implements DoCheck, OnInit {

  value;
  @Input() selected;
  @Output() change = new EventEmitter();

  constructor() {
    this.value = false;
  }

  ngOnInit() {
    if (this.selected === MODES.ADVANCED) { this.value = true; }
  }

  ngDoCheck() {
      if (this.selected === MODES.ADVANCED) { this.value = true; }
  }

  toggleMode() {
    this.change.emit(this.value ? MODES.ADVANCED : MODES.DEFAULT);
  }

}
