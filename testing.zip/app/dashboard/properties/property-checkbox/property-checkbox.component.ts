import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-property-checkbox',
  templateUrl: './property-checkbox.component.html',
  styleUrls: ['./property-checkbox.component.scss']
})
export class PropertyCheckBoxComponent {

  @Input() data: any;
  @Output() propChange = new EventEmitter();

  propertyChanged() {
    this.propChange.emit(this.data.value);
  }

}
