import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-property-dropdown',
  templateUrl: './property-dropdown.component.html',
  styleUrls: ['./property-dropdown.component.scss']
})
export class PropertyDropdownComponent {

  @Input() data: any;
  @Output() propChange = new EventEmitter();

  propertyChanged() {
    this.propChange.emit(this.data.value);
  }

}
