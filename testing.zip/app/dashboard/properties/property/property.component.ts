import { Component, Input } from '@angular/core';
import { DashboardService } from '../../dashboard.service';



const setPropValue = (sectionProps, val, propName) => {
  Object.keys(sectionProps).forEach((key => {
    if (key === propName) {
      sectionProps[key].default = val;
    } else if (sectionProps[key].properties) {
      setPropValue(sectionProps[key].properties, val, propName)
    }
  }));
};

@Component({
  selector: 'app-property',
  templateUrl: './property.component.html',
  styleUrls: ['./property.component.scss']
})
export class PropertyComponent {

  @Input() property: any;

  constructor(private service: DashboardService) {}

  propChanged(val) {
    const sectionProps = this.service.liaisonResult.properties[this.property.sectionName].properties;
    if (sectionProps) {
      setPropValue(sectionProps, val, this.property.propertyName);
    }
  }

}
