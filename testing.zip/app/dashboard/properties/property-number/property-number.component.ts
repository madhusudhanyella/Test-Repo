import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-property-number',
  templateUrl: './property-number.component.html',
  styleUrls: ['./property-number.component.scss']
})
export class PropertyNumberComponent {

  @Input() data: any;
  @Output() propChange = new EventEmitter();

  propChanged() {
    this.propChange.emit(this.data.value);
  }

}
