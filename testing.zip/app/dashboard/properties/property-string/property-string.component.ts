import { Component, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-property-string',
  templateUrl: './property-string.component.html',
  styleUrls: ['./property-string.component.scss']
})
export class PropertyStringComponent {

  @Input() data: any;
  @Output() propChange = new EventEmitter();

  propChanged() {
    this.propChange.emit(this.data.value);
  }

}
