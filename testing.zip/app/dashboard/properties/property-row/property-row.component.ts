import { Component, Input, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-property-row',
  templateUrl: './property-row.component.html',
  styleUrls: ['./property-row.component.scss']
})
export class PropertyRowComponent implements OnInit {

  @Input() data: any;
  @Output() propChange = new EventEmitter();

  ngOnInit() {
    this.data.valueArray = [];
    if (this.data.items.length === 1 && this.data.items[0].type === 'string' && !!this.data.items[0].enum && !!this.data.value) {
      const selectedValues = this.data.value.split(',');
      selectedValues.forEach((key: any) => {
        const obj = [{...this.data.items[0], value: key.trim() }];
        this.data.valueArray.push(obj);
      });
    } else {
      this.data.valueArray = this.data.value;
    }
  }

  addRow() {
    if (!this.data.valueArray) {
      this.data.valueArray = [];
    }
    this.data.valueArray.push(this.data.items.map(item => ({...item, value: ''})));
    if (this.data.items.length === 1 && this.data.items[0].type === 'string' && !!this.data.items[0].enum && !!this.data.value) {
      const vals = this.data.valueArray.reduce((res, cur) => {
        res.push(cur[0].value);
        return res;
      }, []);
      this.propChange.emit(vals.join(', '));
    } else {
      this.propChange.emit(this.data.valueArray);
    }
  }

  propChanged() {
    if (this.data.items.length === 1 && this.data.items[0].type === 'string' && !!this.data.items[0].enum && !!this.data.value) {
      const vals = this.data.valueArray.reduce((res, cur) => {
        res.push(cur[0].value);
        return res;
      }, []);
      this.propChange.emit(vals.join(', '));
    } else {
      this.propChange.emit(this.data.valueArray);
    }
  }

  removeRow(index) {
    if (!this.data.valueArray) {
      this.data.valueArray = [];
    }
    this.data.valueArray = this.data.valueArray.filter((item, i) => index !== i);
    if (this.data.items.length === 1 && this.data.items[0].type === 'string' && !!this.data.items[0].enum && !!this.data.value) {
      const vals = this.data.valueArray.reduce((res, cur) => {
        res.push(cur[0].value);
        return res;
      }, []);
      this.propChange.emit(vals.join(', '));
    } else {
      this.propChange.emit(this.data.valueArray);
    }
  }

}
