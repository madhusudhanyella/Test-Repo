import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';

import { DashboardComponent } from './dashboard.component';
import { FilterOptionsComponent } from './filter-options/filter-options.component';
import { PropertiesComponent } from './properties/properties.component';
import { PropertyStringComponent } from './properties/property-string/property-string.component';
import { PropertyCheckBoxComponent } from './properties/property-checkbox/property-checkbox.component';
import { PropertyNumberComponent } from './properties/property-number/property-number.component';
import { PropertyDropdownComponent } from './properties/property-dropdown/property-dropdown.component';
import { PropertyRowComponent } from './properties/property-row/property-row.component';
import { PropertyComponent } from './properties/property/property.component';
import { MaterialLoaderModule } from '../material-loader.module';
import { DashboardService } from './dashboard.service';

const machineRoutes =
    [
        { path: '', component: DashboardComponent }
    ];


@NgModule(
    {
        imports:
            [
                CommonModule,
                RouterModule.forChild(machineRoutes),
                FormsModule,
                MaterialLoaderModule
            ],
        declarations: [
            DashboardComponent,
            FilterOptionsComponent,
            PropertiesComponent,
            PropertyStringComponent,
            PropertyCheckBoxComponent,
            PropertyNumberComponent,
            PropertyDropdownComponent,
            PropertyRowComponent,
            PropertyComponent
           ],
        entryComponents: [
            DashboardComponent,
            FilterOptionsComponent,
            PropertiesComponent,
            PropertyStringComponent,
            PropertyCheckBoxComponent,
            PropertyNumberComponent,
            PropertyDropdownComponent,
            PropertyRowComponent,
            PropertyComponent
        ],
        providers: [DashboardService]
    })
export class DashboardModule { }
