import { Component, OnInit } from '@angular/core';
import * as _ from 'lodash';
import { liaisonData } from './testData';
import { optionsData } from './dashboard.config';
import { DashboardService } from './dashboard.service';


const mapItems = (itemsObj) =>  {
  const itemsPropertiesObj = itemsObj.properties;
  if (itemsPropertiesObj) {
    const items = [];
    Object.keys(itemsPropertiesObj).forEach((itemPropKey) => {
      const item = {...itemsPropertiesObj[itemPropKey]};
      item.itemName = itemPropKey;
      items.push(item);
    });
    return items;
  } else {
    return [itemsObj];
  }
};

const mapSubProperties = (subPropertiesObj, filterOption, sectionName) => {
  const subPropertiesList = [];
  Object.keys(subPropertiesObj).forEach((subPropKey) => {
    const subProperty = {...subPropertiesObj[subPropKey]};
    if (subProperty.category === filterOption && !!subProperty.description) {
      subProperty.propertyName = subPropKey;
      subProperty.value = subProperty.default;
      const itemsObj = subProperty.items;
      if (itemsObj) {
        subProperty.items = mapItems(itemsObj);
      }
      const childProperties = subProperty.properties;
      if (childProperties) {
        subProperty.properties = mapSubProperties(childProperties, filterOption, sectionName);
      }
      subProperty.sectionName = sectionName;
      subPropertiesList.push(subProperty);
    }
  });
  return subPropertiesList;
};

const mapProperty = (property, propertyName, sectionName, filterOption) => {
  property.propertyName = propertyName;
  property.sectionName = sectionName;
  property.value = property.default;
  const subPropertiesObj = property.properties;
  if (subPropertiesObj) {
    const newSubProperties = mapSubProperties(subPropertiesObj, filterOption, sectionName);
    property.properties = newSubProperties;
  }
  const itemsObj = property.items;
  if (itemsObj) {
    property.items = mapItems(itemsObj);
  }
  return property;
};

const mapProperties = (sectionsObj, filterOption) => {
  const properties = [];
  Object.keys(sectionsObj).forEach((sectionKey) => {
    const propertiesObj = sectionsObj[sectionKey].properties;
    if (propertiesObj) {
      Object.keys(propertiesObj).forEach((propKey) => {
        const property = {...propertiesObj[propKey]};
        if (!!property.description) {
          if (property.category === filterOption) {
            const newProperty = mapProperty(property, propKey, sectionKey, filterOption);
            if (property.properties) {
              if (newProperty.properties && newProperty.properties.length > 0) {
                properties.push(newProperty);
              }
            } else {
              properties.push(newProperty);
            }
          } else if (property.properties) {
            const subPropertiesCategories = Object.keys(property.properties).map(key => property.properties[key]).map(obj => obj.category);
            if (subPropertiesCategories.indexOf(filterOption) !== -1) {
              const newProperty = mapProperty(property, propKey, sectionKey, filterOption);
              if (newProperty.properties && newProperty.properties.length > 0) {
                properties.push(newProperty);
              }
            }
          }
        }
      });
    }
  });
  return properties;
};

@Component({
    selector: 'app-dashboard',
    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {
    optionsData: any;
    defaultOption: any;
    // fileName: any = 'No File Chosen';
    properties: any;
    // fileData: any = {};

    constructor(private service: DashboardService) {}

    ngOnInit() {
        this.optionsData = optionsData;
        this.defaultOption = this.optionsData && this.optionsData.length && this.optionsData[0] && this.optionsData[0].value;
        this.properties = mapProperties(liaisonData.properties, this.defaultOption);
        this.service.liaisonResult = _.cloneDeep(liaisonData);
    }

    onOptionClick(option) {
        this.properties = mapProperties(this.service.liaisonResult ? this.service.liaisonResult.properties : {}, option);
    }

    save() {
      
    }

    // readFile(event) {
    //     const selectedFile = event.target.files[0];
    //     this.fileName = selectedFile.name;
    //     const fileReader = new FileReader();
    //     fileReader.readAsText(selectedFile, 'UTF-8');
    //     fileReader.onload = (e: any) => {
    //         const fileResult = JSON.parse(e.target.result);
    //         this.fileData = fileResult;
    //         if (fileResult.properties) {
    //             this.properties = mapProperties(fileResult.properties, this.defaultOption);
    //         }
    //     }
    //     fileReader.onerror = (error) => {
    //         console.log(error);
    //     }
    // }
}
